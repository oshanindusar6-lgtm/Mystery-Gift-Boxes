MYSTERY BUNNY WEBSITE — SETUP GUIDE (සිංහල)

ඔයාගේ Mystery Bunny website starter files මෙන්න. Pastel pink / purple / blue theme එක සහ Rs. 1,000 / 2,000 / 3,000 package options ඇතුළත්.

1) WhatsApp number එක දාන්න
- index.html file එක text editor එකකින් open කරන්න.
- `const WHATSAPP_NUMBER = "947XXXXXXXX";` කියන line එක හොයන්න.
- ඒක ඔයාගේ WhatsApp number එකෙන් replace කරන්න. ශ්‍රී ලංකාව සඳහා format example: `94771234567`
- + ලකුණක්, spaces හෝ hyphens දාන්න එපා. උදාහරණ number එක වෙනුවට ඔයාගේ number එකම දාන්න.
- Save කරන්න.

2) Website එක බලන්න
- index.html file එක browser එකක open කරන්න.

3) Online publish කරන්න
- GitHub Pages වැනි static hosting service එකක් භාවිතා කර index.html publish කරන්න.
- Publish වුණාම ලැබෙන website link එක TikTok / Facebook bio එකට දාන්න.
- Hosting service එකේ current setup instructions අනුගමනය කරන්න.

වැදගත්:
- මේක static starter website එකක්. WhatsApp button එකෙන් pre-filled order message එකක් open වෙනවා; customer තමයි WhatsApp එකෙන් message එක send කරන්නේ.
- Database, admin panel, automatic checkout, online payment, order tracking හෝ stock management ඇතුළත් නැහැ.
- Spin Wheel එක browser demo එකක් විතරයි. ඒකෙන් real prize, discount හෝ order entitlement එකක් ලැබෙන්නේ නැහැ. Real promotion එකක් කරනවා නම් prizes, odds, limits සහ terms පැහැදිලි කරලා site එක update කරන්න.
- Orders ගන්න කලින් package contents, shipping fee, delivery estimate, payment method සහ return/refund policy WhatsApp හරහා පැහැදිලි කරන්න.
- Rs. 5,000–10,000 budget එකෙන් stock, packaging, delivery samples, data සහ promotion සඳහා මුදල් වෙන්කරගන්න. Domain/hosting cost service එක අනුව වෙනස් වෙන්න පුළුවන්.
